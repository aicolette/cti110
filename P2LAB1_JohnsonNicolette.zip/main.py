miles_per_gallon = float(input())



dollars_per_gallon = float(input())



dollars_per_mile = dollars_per_gallon/miles_per_gallon



your_value1 = 20 * dollars_per_mile



your_value2 = 75 * dollars_per_mile


your_value3 = 500 * dollars_per_mile

print('{:.2f} {:.2f} {:.2f}'.format(your_value1, your_value2, your_value3))

