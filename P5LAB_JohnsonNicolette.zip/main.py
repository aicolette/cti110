def days_in_feb(year):
   is_leap = True
   if (year % 4) == 0:
       if (year % 100) == 0:
           if (year % 400) == 0:
               is_leap = True
               days = 29
           else:
               is_leap = False
               days = 28
       else:
           is_leap = True
           days = 29
   else:
       is_leap = False
       days = 28
   return days

def get_user_input():
    year = int(input())
    print(year, "has", days_in_feb(year), "days in February.")


if __name__ == '__main__':
    get_user_input()
 